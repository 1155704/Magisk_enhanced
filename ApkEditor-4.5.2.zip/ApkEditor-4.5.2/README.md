**Release** 

[![Android](https://img.shields.io/badge/Platform-Android-green.svg?style=flat-square)](https://www.android.com) [![API](https://img.shields.io/badge/API-21%2B-orange.svg?logo=android&style=flat-square)](https://developer.android.com/studio/releases/platforms) [![Release](https://img.shields.io/github/v/release/PatrickAlex2019/ApkEditor?style=flat-square)](https://github.com/PatrickAlex2019/ApkEditor/releases)

**Preview**

![alt text](https://raw.githubusercontent.com/PatrickAlex2019/ApkEditor/master/APKEditor_Preview1.PNG)


**Download** 

[![Download](https://img.shields.io/github/downloads/PatrickAlex2019/ApkEditor/total?color=brightgreen&label=Download&style=for-the-badge)](https://github.com/PatrickAlex2019/ApkEditor/releases)

[![Telegram](https://img.shields.io/static/v1?label=Telegram&message=Channel&color=0088cc)](https://t.me/anubis_recommended)

**Attention**

- It is only for learning and communication, and is not allowed to be used for business

**Thanks**

• Candyman(Compile)

• Patrick Alex(Signature) 

• MonetCarlos(Translate & Repair)

• ガルシア(Add monet style)

• Zeratul(Original creator)

• Aidos Zhaqyp

• Mr Ikso

• keks40

• Bin(APK alignment optimization) 
